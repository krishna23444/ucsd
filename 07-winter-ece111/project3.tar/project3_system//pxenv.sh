pxhdllibpath_designs_test3_mentor_com_platformexpress_ip_arm_processors_ahbmemory_1=/saumya/seamless/3rd-Proj/work/@ahb@memory
export pxhdllibpath_designs_test3_mentor_com_platformexpress_ip_arm_processors_ahbmemory_1
pxhdllibpath_designs_test3_mentor_com_platformexpress_ip_arm_processors_ahbmemory_2=/saumya/seamless/3rd-Proj/work/@ahb@memory
export pxhdllibpath_designs_test3_mentor_com_platformexpress_ip_arm_processors_ahbmemory_2
pxhdllibpath_designs_test3_mentor_com_platformexpress_ip_arm_processors_a946_1=/saumya/seamless/3rd-Proj/work/a946
export pxhdllibpath_designs_test3_mentor_com_platformexpress_ip_arm_processors_a946_1
pxhdllibpath_designs_test3=/saumya/seamless/3rd-Proj/work/test3
export pxhdllibpath_designs_test3
pxhdllibpath_pxdefault_tb=/saumya/seamless/3rd-Proj/work/pxdefault_tb
export pxhdllibpath_pxdefault_tb
pxhdllibpath_base=/saumya/seamless/3rd-Proj/work
export pxhdllibpath_base
#pxhdlsrcfile_a946_1_A946_mod_v=/home/saumya/softwares/platform_express/pxLibraries/com.mentor.PlatformExpress.ip.ARM.processors_1.0.0/componentLibrary/component/a946/1.1/hdlsrc/A946_mod.v
#pxhdlsrcfile_AhbMemory_1_pxAhbMem_v=/home/saumya/softwares/platform_express/pxLibraries/com.mentor.PlatformExpress.ip.ARM.processors_1.0.0/componentLibrary/component/AhbMemory/1.0/hdlsrc/pxAhbMem.v
#pxhdlsrcfile_pxgen_PxDecoder_AHB_1_1407810334_module_v=/home/saumya/workspace/armdemo/build/test3/verificationEnv/Modelsim/hdl/PxDecoder_AHB_1_1407810334_module.v
#pxhdlsrcfile_pxgen_test3_v=/home/saumya/workspace/armdemo/build/test3/verificationEnv/Modelsim/hdl/test3.v
#pxhdlsrcfile_pxgen_pxdefault_tb_v=/home/saumya/workspace/armdemo/build/test3/verificationEnv/Modelsim/testbench/pxdefault_tb/pxdefault_tb.v
PX_BUILD=/saumya/seamless/3rd-Proj/sw/check-mycompile 
#Modelsim/software/a946_1_Memory
#a946_1_uARM946E_Sr1=/home/saumya/softwares/platform_express/pxLibraries/com.mentor.PlatformExpress.ip.ARM.processors_1.0.0/componentLibrary/component/a946/1.1/software/boot/init.s
a946_1=/home/saumya/softwares/platform_express/pxLibraries/com.mentor.PlatformExpress.ip.ARM.processors_1.0.0/componentLibrary/component/a946/1.1
com_mentor_PlatformExpress_ip_ARM_processors_1_0_0=/home/saumya/softwares/platform_express/pxLibraries/com.mentor.PlatformExpress.ip.ARM.processors_1.0.0
#a946_1_uARM946E_Sr1_0=${a946_1}/software/boot/reset_vectors.s
#a946_1_uARM946E_Sr1_1=${a946_1}/software/boot/interrupt_handler.c
#PX_BUILD_uARM946E_Sr1=${a946_1}/software/boot
#PX_BUILD_uARM946E_Sr1_0=${com_mentor_PlatformExpress_ip_ARM_processors_1_0_0}/lib/software/src
AhbMemory_1=${com_mentor_PlatformExpress_ip_ARM_processors_1_0_0}/componentLibrary/component/AhbMemory/1.0
#PX_BUILD_uARM946E_Sr1_1=${PX_BUILD}/coreDiagnostics/_a946_1
#pxcvefile_run=/home/saumya/workspace/armdemo/build/test3/verificationEnv/Modelsim/exec/run.cve
#pxhdlsimexecfile=/home/saumya/workspace/armdemo/build/test3/verificationEnv/Modelsim/exec/hw_batch.sh
#pxhdlsimexecfile_0=/home/saumya/workspace/armdemo/build/test3/verificationEnv/Modelsim/exec/hw.sh
#pxantfile_properties=/home/saumya/workspace/armdemo/build/test3/verificationEnv/Modelsim/pxenv.properties
#pxshellfile_properties=/home/saumya/workspace/armdemo/build/test3/verificationEnv/Modelsim/pxenv.sh
#pxcvefile_run_0=${pxcvefile_run}
#pxhdlsimexecfile_1=${pxhdlsimexecfile}
#pxhdlsimexecfile_2=${pxhdlsimexecfile_0}

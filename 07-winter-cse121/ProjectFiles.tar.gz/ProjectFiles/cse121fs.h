/*
 * CSE121 Project 2: File System
 *
 * Copyright(c) 2005 Alex C. Snoeren <snoeren@cs.ucsd.edu>
 *
 */

#define BLOCKSIZE 512

#define DISKFILE "disk.txt"

/* You must use the following two calls to read from your "disk" */
/* Read a block from disk */
int dread(int fd, int blocknum, char *buf);

/* Write a block to disk */
int dwrite(int fd, int blocknum, char *buf);


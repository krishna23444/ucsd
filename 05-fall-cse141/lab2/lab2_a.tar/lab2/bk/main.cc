#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <vector>
#include <time.h>
#include <stdio.h>
#include "proc.h"
#include "main.h"
using namespace std;

int main(int argc, char* argv[]) {
   FILE *infile;
   FILE *indfile;
   FILE *outfile;
	char option;
   int advancement = 0;
   // Proc p;			// Define the class
   char * str;

   bool options = false;

   if ((argc == 1) && (strcmp("-help", argv[1])) ) {
      printf( "\t%s: <machine code file> ", argv[0]);
      printf( "<data memory file> <output file>\n");
      return 0;
   }

	while ((option = getopt(argc, argv, "a:hi:d:o:")) != EOF) {
      options = true;
		switch(option) {
			case 'a':
			break;
			case 'h':
            printf( "\t%s: <machine code file> ", argv[0]);
            printf( "<data memory file> <output file>\n");
            return 0;
			break;
         case 'i':
            infile = fopen(optarg, "r");
         break;
         case 'd':
            indfile = fopen(optarg, "r");
         break;
         case 'o':
            outfile = fopen(optarg, "w");
         break;
      }
   }
   // Command line options

   // No options, so manually define as the argv1-3
   if (!options) {
      // Define the i-mem file
      infile = fopen (argv[1], "r");
      // Define the d-mem file in
      indfile = fopen (argv[2], "r");
      // Define the d-mem file out
      outfile = fopen (argv[3], "w");
   }

   if (indfile == NULL) {
      cout << "Data input file does not exist" << endl;
      return 0;
   }

   if (infile == NULL) {
      cout << "Instruction input file does not exist" << endl;
      return 0;
   }

/*
   // Load instruction and data mem into the ISS
   p.reset();

   p.loadIMem(infile);
   p.loadDMem(indfile);

   // Run the loop
   p.runLoop();

   printHeaderInFile("D-Mem Dump", outfile);

   p.dumpDMem(outfile);
   p.PrintInstCount(outfile);
*/
   fclose(infile);
   fclose(indfile);
   fclose(outfile);


}

void printHeaderInFile(char * str, FILE * file) {
	//fprintf(file, "########## %s ##########\n", str);
}

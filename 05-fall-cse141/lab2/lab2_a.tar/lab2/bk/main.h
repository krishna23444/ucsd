void printHeaderInFile(char * str, FILE * file);

void interactive(int, char**);

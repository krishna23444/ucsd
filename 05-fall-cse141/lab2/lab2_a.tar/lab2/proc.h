#ifndef PROC_H__
#define PROC_H__

#include <cstdio>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>
#include "instruction.h"
using namespace std;

//
class Proc {
public:
  Proc();
  ~Proc();

  void Init();

  int Lookup(const string& reg_name);

  void loadIMem(FILE *fin);
  void loadDMem(FILE *fin);

  void dumpIMem(FILE *fout=stdout, int start=0, int end=-1);
  void dumpDMem(FILE *fout=stdout, int start=0, int end=-1);

  void reset();

  void Fetch();
  void Decode();
  void Execute();
  void WriteResult();
  void SetNextPC();
  void GenerateInstructionTrace();

  void runLoop(int num_inst=256);

  void generate_trace();

  void PrintInstCount(FILE *fout=stdout);

private:
  static const string NUMS[];
  static const string REGS[];
  static map<string, int> reg_lookup;
  vector<Instruction> CMDS;

  // runLoop variables
  bool halted;
  int inst;
  string cmd;
  int op1, op2, result;
  bool alu_bit_flag;

  // registers
  unsigned char regs[8];

  // Instruction Memory
  vector<unsigned char> imem;

  // Data Memory
  vector<unsigned char> dmem;

  // Program Counter
  unsigned char pc;

  // Dynamic instruction count
  unsigned int dyn_inst_count;
};

#endif

/*#################################################################
### main.cc for lab2 of CSE141L
### 
### This program takes many options:
###   -a #     - advance the program by N instructions
###   -h       - output help
###   -i []    - instruction input file
###   -d []    - initial d-mem file
###   -o []    - output file
###   -r       - range of instructions
###   -s       - if set, then dump instructions
###   -t       - if set, then dump data
###   -u #     - if set, then dump # of registers
###   -help    - output help
###
### DEFAULT:
###   [exec file] <machine code file> <data memory file> <output file>
#################################################################*/

#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <vector>
#include <time.h>
#include <stdio.h>
#include "proc.h"
#include "main.h"
using namespace std;

int main(int argc, char* argv[]) {
   FILE *infile;
   FILE *indfile;
   FILE *outfile;
   char option;
   int advancement = 0;
   // Proc p;			// Define the class
   char * str;
   bool options = false;
   bool dumpI = false;
   bool dumpD = false;
   bool outputset = false;
   bool printC = false;
   bool dumpR = 0;
   int instructions = 256;
   if ((argc == 2) && (strcmp("-help", argv[1])) ) {
      printHelp(argv);
      return 0;
   }


   while ((option = getopt(argc, argv, "a:hi:d:o:str:u:p")) != EOF) {
      options = true;
      switch(option) {
         case 'a':
            advancement = atoi(optarg);
         break;
         case 'h':
            printHelp(argv);
            return 0;
         break;
         case 'i':
            infile = fopen(optarg, "r");
         break;
         case 'd':
            indfile = fopen(optarg, "r");
         break;
         case 'o':
            outfile = fopen(optarg, "w");
            outputset = true;
         break;
         case 'p':
            printC = true;
         break;
         case 's':
            dumpI = true;
         break;
         case 't':
            dumpD = true;
         break; 
         case 'r':
            instructions = atoi(optarg);
         break;
         case 'u':
            dumpR = atoi(optarg);
         break;
      }
   }
   // Command line options
   // No options, so manually define as the argv1-3
   if (!options) {
      if (argc < 4) {
         printf("Invalid input\n");
         printHelp(argv);
         return 0;
      }
      // Define the i-mem file
      infile = fopen (argv[1], "r");
      // Define the d-mem file in
      indfile = fopen (argv[2], "r");
      // Define the d-mem file out
      outfile = fopen (argv[3], "w");

      outputset = true;
   }

   if (indfile == NULL) {
      printf("Data input file does not exist\n"); 
      return 0;
   }

   if (infile == NULL) {
      printf("Instruction input file does not exist\n");
      return 0;
   }

   // If there are no options set, revert to default mode
   // Which means you need a valid output file
   if ((outfile == NULL) && (!options)) {
      printf("Data output file does not exist\n"); 
      return 0;
   }

/*
   // Load instruction and data mem into the ISS
   p.reset();

   p.loadIMem(infile);
   p.loadDMem(indfile);

   // Run the loop
   p.runLoop(instructions);

   printHeaderInFile("D-Mem Dump", outfile);

   // Dump DMem to the output file if it is in default or stated
   if ((dumpD && outputset) || (!options)) {
      p.dumpDMem(outfile);
      p.PrintInstCount(outfile);
   } else if (dumpD) {
      dumpDMem(NULL, advance, instructions);
   }

   // Dump IMem
   if (dumpI) {
      p.dumpIMem(NULL, advance, instructions);
   }

   // Dump Registers
   if (dumpR) {
   }


*/
   fclose(infile);
   fclose(indfile);
   fclose(outfile);

   return 0;
}

void printHeaderInFile(char * str, FILE * file) {
   //fprintf(file, "########## %s ##########\n", str);
}

void printHelp(char * argv[]) {
      printf( "\t%s: <machine code file> ", argv[0]);
      printf( "<data memory file> <output file>\n");
      printf( "\t-a #     - advance the program by N instructions\n");
      printf( "\t-h       - output help\n");
      printf( "\t-i []    - instruction input file\n");
      printf( "\t-d []    - initial d-mem file\n");
      printf( "\t-o []    - output file\n");
      printf( "\t-s       - if set, then dump instructions\n");
      printf( "\t-t       - if set, then dump data\n");
      printf( "\t-u #     - if set, then dump # of registers\n");
      printf( "\t-help    - output help\n");
}

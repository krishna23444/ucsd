#ifndef INSTRUCTION_H__
#define INSTRUCTION_H__

#include <string>
using namespace std;

struct Instruction {
  char num_ops;
  char op1_mask;
  char op1_shift;
  char op2_mask;
  char op2_shift;
  bool writes_to_reg;
  bool writes_to_mem;
  bool reads_from_reg;
  bool reads_from_mem;
  bool is_branch;
  char branch_dist;
  string cmd_name;
  char machine_code;

  void clear();

  char op1() const;
  char op2() const;
};

#endif

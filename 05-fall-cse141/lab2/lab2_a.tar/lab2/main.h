void printHeaderInFile(char * str, FILE * file);
void printHelp(char**);
void interactive(int, char**);
